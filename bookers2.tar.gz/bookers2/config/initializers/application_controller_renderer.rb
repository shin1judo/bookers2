# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '69077001c0590bb6cd8edaa709fc0f40a17f5c1cb4172729d0d89370e1eff662daeb701097171dd675ab8a7c10a11784d239f0b441b4b33c65384ebdf3a41b3c'